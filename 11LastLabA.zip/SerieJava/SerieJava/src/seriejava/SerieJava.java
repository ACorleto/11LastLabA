/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seriejava;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class SerieJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int A;
       
        System.out.println("Ingrese un numero");
        Scanner M1 = new Scanner(System.in);
        A = M1.nextInt();
        
        if (A%2==0){
            System.out.println(A+" Es un Numero Par");
        }else{
            System.out.println(A+" Es un Numero Impar");}
       
        
        
        String Nombre = "";       
        System.out.println("Ingrese su Nombre");
        Scanner D1 = new Scanner(System.in);
        Nombre = D1.nextLine();
       
        System.out.println("Alumno "+ Nombre+" Que tengas suerte en tu laboratorio!");
        }
    }
    
