/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication;
import java.util.Scanner
/**
 *
 * @author estudiante
 */
public class SerieJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Condicional if
        int A;
        //Entrada de datos if
        System.out.println("Ingrese un numero");
        Scanner A1 = new Scanner(System.in);
        A = A1.nextInt();
        //Salida de datos if
        if (A%2==0){
            System.out.println(A+" Es un Numero Par");
        }else{
            System.out.println(A+" Es un Numero Impar");}
        //Metodo de Salida
        String Nombre = "";
        //Entrada de datos
        System.out.println("Ingrese su Nombre");
        Scanner N1 = new Scanner(System.in);
        Nombre = N1.nextLine();
        //Salida de datos
        System.out.println("Suerte en Tu Laboratorio "+ Nombre);
        }
    }
    
